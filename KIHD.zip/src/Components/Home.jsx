import { Container, Grid } from "@mui/material";
import React from "react";
import SignIn from "./SignIn";
import { useTheme } from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";

const Home = () => {
  const theme = useTheme();
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("md"));

  return (
    <>
      <section>
        <div className="heading">
          <h3 className="wlcm-txt">Welcome to KoliInfotech Helpdesk (KIHD)</h3>
          <p className="text">IT, HR, Admin, DevOps/Release Engineering</p>
        </div>

        <Container
          maxWidth="l"
          sx={{
            border: "1px solid red",
            width: "100%",
            px: { xs: 0, sm: 0, md: 0, lg: 3 },
          }}
        >
          <Grid
            container
            spacing={2}
            direction={isSmallScreen ? "column" : "row"} // Change direction based on screen size
          >
            <Grid
              item
              xs={12}
              sm={6}
              lg={8}
              sx={{ display: { xs: "none", sm: "block" } }}
            >
              <div
                className="asid-txt"
                style={{ border: "1px solid green", padding: "16px" }}
              >
                <p
                  style={{
                    paddingBottom: "16px",
                    fontWeight: "300",
                    fontSize: "1rem",
                  }}
                >
                  <strong>Important Information:</strong>
                </p>
                <ul className="key-points">
                  <li>
                    KoliInfotech Helpdesk (KIHD) is a tool, providing
                    centralised support service for our work needs.
                  </li>
                  <li>
                    KIHD is a one stop solution platform for issues related to -
                    IT, HR, Admin, DevOps/Release Engineering
                  </li>
                  <li>
                    To login to KoliInfotech Helpdesk application, associates
                    shall use same <strong>login name and password </strong>
                    which is used to login to koliinfotech.com.
                  </li>
                  <li>
                    For any <strong>technical issues </strong>with the
                    application please contact the support team at{" "}
                    <a
                      href="mailto:info@koliinfotech.com"
                      style={{ color: "#2e5c9e" }}
                    >
                      info@koliinfotech.com
                    </a>
                  </li>
                  <li>
                    For any <strong>login issue </strong>please contact the
                    Systems team at{" "}
                    <a
                      href="mailto:info@koliinfotech.com"
                      style={{ color: "#2e5c9e" }}
                    >
                      info@koliinfotech.com
                    </a>
                  </li>
                </ul>
              </div>
            </Grid>
            <Grid
              item
              xs={12}
              sm={6}
              lg={4}
              sx={{
                border: "1px solid orange",
                px: { xs: 0, sm: 0, lg: 0 },
                my: 0,
              }}
            >
              <div className="form" style={{ border: "1px solid blue" }}>
                <SignIn />
              </div>
            </Grid>
          </Grid>
        </Container>
      </section>
    </>
  );
};

export default Home;
